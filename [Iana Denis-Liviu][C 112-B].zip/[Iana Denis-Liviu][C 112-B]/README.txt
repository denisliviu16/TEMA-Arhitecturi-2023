Modificari pentru a verifica testele se gasesc la urmatoarele linii din cod:

- 86 pentru CH ( exemplul din enuntul temei pentru verificarea functiei SEED )
- 87 pentru CL
- 88 pentru DH
- 89 pentru DL

- 144 pentru x0
- 145 pentru x
- 146 pentru NUMAR ( aici se stocheaza x0 pentru afisare )

- 184 pentru variabila a
- 185 pentru variabila b


